﻿namespace WindowsFormsApp5
{
    partial class greyMovie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(greyMovie));
            this.bashliq = new System.Windows.Forms.Label();
            this.biletAlmaq = new System.Windows.Forms.Button();
            this.qiymet = new System.Windows.Forms.TextBox();
            this.yekunQiymet = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // bashliq
            // 
            this.bashliq.AutoSize = true;
            this.bashliq.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bashliq.Font = new System.Drawing.Font("Modern No. 20", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bashliq.ForeColor = System.Drawing.Color.DarkRed;
            this.bashliq.Location = new System.Drawing.Point(55, 9);
            this.bashliq.Name = "bashliq";
            this.bashliq.Size = new System.Drawing.Size(158, 31);
            this.bashliq.TabIndex = 0;
            this.bashliq.Text = "Oturacaglar";
            // 
            // biletAlmaq
            // 
            this.biletAlmaq.Location = new System.Drawing.Point(675, 92);
            this.biletAlmaq.Name = "biletAlmaq";
            this.biletAlmaq.Size = new System.Drawing.Size(75, 23);
            this.biletAlmaq.TabIndex = 1;
            this.biletAlmaq.Text = "Bilet almaq";
            this.biletAlmaq.UseVisualStyleBackColor = true;
            this.biletAlmaq.Click += new System.EventHandler(this.biletAlmaq_Click);
            // 
            // qiymet
            // 
            this.qiymet.Location = new System.Drawing.Point(675, 55);
            this.qiymet.Name = "qiymet";
            this.qiymet.Size = new System.Drawing.Size(75, 20);
            this.qiymet.TabIndex = 2;
            this.qiymet.Text = "qiymet";
            // 
            // yekunQiymet
            // 
            this.yekunQiymet.Location = new System.Drawing.Point(643, 134);
            this.yekunQiymet.Name = "yekunQiymet";
            this.yekunQiymet.Size = new System.Drawing.Size(136, 20);
            this.yekunQiymet.TabIndex = 3;
            // 
            // greyMovie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 261);
            this.Controls.Add(this.yekunQiymet);
            this.Controls.Add(this.qiymet);
            this.Controls.Add(this.biletAlmaq);
            this.Controls.Add(this.bashliq);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "greyMovie";
            this.Text = "greyMovie";
            this.Load += new System.EventHandler(this.greyMovie_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label bashliq;
        private System.Windows.Forms.Button biletAlmaq;
        private System.Windows.Forms.TextBox qiymet;
        private System.Windows.Forms.TextBox yekunQiymet;
    }
}