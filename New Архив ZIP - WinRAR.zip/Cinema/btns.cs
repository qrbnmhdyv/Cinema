﻿namespace WindowsFormsApp5
{
    internal class btns
    {
    }
}