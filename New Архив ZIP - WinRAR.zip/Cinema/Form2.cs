﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class greyMovie : Form
    {
        public greyMovie()
        {
            InitializeComponent();
        }
        public int b = 20;
        public new int Top = 50;
        public new int Left = 40;
        List<Button> selectList = new List<Button>();

        public object Button1 { get; private set; }
        

        private void greyMovie_Load(object sender, EventArgs e)
        {
            Width = 900;
            Height = 500;
            bashliq.Left = 250;
         
            for (int a = 0; a < 10; a++)
            {
                
                for (int i = 0; i < b; i++)
                {
                    var btn = new Button();
                    Controls.Add(btn);
                    btn.BackColor = Color.Silver;
                    btn.Width = 30;
                    btn.Height = 30;
                    btn.Left = Left;
                    btn.Top = Top;
                    Left += btn.Width;
              
                    if (Left-40 == btn.Width*20)
                    {                   
                        Top += btn.Height;
                        Left = 40;
                    }
                   
                    btn.Click += new EventHandler(this.GreetingBtn_Click);
                    
                }
            }
         
           
        }
        int count = 1;
        private void GreetingBtn_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            bool say = false;

            Button deyer = new Button();
                foreach (var item in selectList)
                {
                    if (item == clickedButton)
                    {
                        if (item.BackColor == Color.Red)
                        {
                        say = true;
                        item.BackColor = Color.Silver;
                        count--;
                        qiymet.Text = Convert.ToString(count * 5-5 + "Azn");
                        deyer = item;
                            if (count == 1)
                            {
                                qiymet.Text = "0 Azn";
                            }
                        }
                    if ((item.BackColor == Color.Black))
                    {
                        say = true;
                        MessageBox.Show("rezerve");
                    }
                        say = true;
                    }
                }
            selectList.Remove(deyer);
                if (say == false)
                {
                    clickedButton.BackColor = Color.Red;
                    selectList.Add(clickedButton);
                    qiymet.Text = Convert.ToString(count * 5 + "Azn");
                    count++;
                }
            
        }

        private void biletAlmaq_Click(object sender, EventArgs e)
        {
            foreach (var item in selectList)
            {
                item.BackColor = Color.Black;
               
            }
            yekunQiymet.Text = "Odeyeceyiniz mebleg"+Convert.ToString(  count * 5 - 5 + "Azn -dir");
            count = 1;
            qiymet.Text = "";
          

        }

    }
}
