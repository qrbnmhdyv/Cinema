﻿namespace WindowsFormsApp5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.grey = new System.Windows.Forms.PictureBox();
            this.sin = new System.Windows.Forms.PictureBox();
            this.secret = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grey)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secret)).BeginInit();
            this.SuspendLayout();
            // 
            // grey
            // 
            this.grey.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("grey.BackgroundImage")));
            this.grey.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.grey.Location = new System.Drawing.Point(43, 109);
            this.grey.Name = "grey";
            this.grey.Size = new System.Drawing.Size(183, 266);
            this.grey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.grey.TabIndex = 0;
            this.grey.TabStop = false;
            this.grey.Click += new System.EventHandler(this.grey_Click);
            // 
            // sin
            // 
            this.sin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sin.BackgroundImage")));
            this.sin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sin.Location = new System.Drawing.Point(311, 71);
            this.sin.Name = "sin";
            this.sin.Size = new System.Drawing.Size(169, 246);
            this.sin.TabIndex = 8;
            this.sin.TabStop = false;
            this.sin.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // secret
            // 
            this.secret.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("secret.BackgroundImage")));
            this.secret.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.secret.Location = new System.Drawing.Point(557, 109);
            this.secret.Name = "secret";
            this.secret.Size = new System.Drawing.Size(158, 266);
            this.secret.TabIndex = 9;
            this.secret.TabStop = false;
            this.secret.Click += new System.EventHandler(this.secret_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(88, 378);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "saat 20:00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(636, 378);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "00:00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(372, 320);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "22:00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Location = new System.Drawing.Point(334, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 35);
            this.label4.TabIndex = 13;
            this.label4.Text = "Movies";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(764, 478);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.secret);
            this.Controls.Add(this.sin);
            this.Controls.Add(this.grey);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grey)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secret)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox grey;
        private System.Windows.Forms.PictureBox sin;
        private System.Windows.Forms.PictureBox secret;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

